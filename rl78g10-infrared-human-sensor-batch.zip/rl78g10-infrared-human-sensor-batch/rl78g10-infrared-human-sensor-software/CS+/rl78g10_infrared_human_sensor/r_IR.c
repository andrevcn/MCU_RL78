/***********************************************************************************************************************
* DISCLAIMER
* This software is supplied by Renesas Electronics Corporation and is only intended for use with Renesas products.
* No other uses are authorized. This software is owned by Renesas Electronics Corporation and is protected under all
* applicable laws, including copyright laws. 
* THIS SOFTWARE IS PROVIDED "AS IS" AND RENESAS MAKES NO WARRANTIESREGARDING THIS SOFTWARE, WHETHER EXPRESS, IMPLIED
* OR STATUTORY, INCLUDING BUT NOT LIMITED TO WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
* NON-INFRINGEMENT.  ALL SUCH WARRANTIES ARE EXPRESSLY DISCLAIMED.TO THE MAXIMUM EXTENT PERMITTED NOT PROHIBITED BY
* LAW, NEITHER RENESAS ELECTRONICS CORPORATION NOR ANY OF ITS AFFILIATED COMPANIES SHALL BE LIABLE FOR ANY DIRECT,
* INDIRECT, SPECIAL, INCIDENTAL OR CONSEQUENTIAL DAMAGES FOR ANY REASON RELATED TO THIS SOFTWARE, EVEN IF RENESAS OR
* ITS AFFILIATES HAVE BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.
* Renesas reserves the right, without notice, to make changes to this software and to discontinue the availability 
* of this software. By using this software, you agree to the additional terms and conditions found by accessing the 
* following link:
* http://www.renesas.com/disclaimer
*
* Copyright (C) 2012, 2017 Renesas Electronics Corporation. All rights reserved.
***********************************************************************************************************************/

/***********************************************************************************************************************
* File Name    : r_IR.c
* Version      : V1.05
* Device(s)    : R5F10Y16
* Tool-Chain   : CCRL
* Description  : This file implements infrared emitting and receiving.
* Creation Date: 2017/10/18
***********************************************************************************************************************/

/***********************************************************************************************************************
Includes <System Includes> , <Project Includes>
***********************************************************************************************************************/
#include "r_cg_macrodriver.h"
#include "r_cg_port.h"
#include "r_cg_intp.h"
#include "r_cg_tau.h"
#include "r_IR.h"
#include "r_cg_userdefine.h"

/***********************************************************************************************************************
Global variables and functions
***********************************************************************************************************************/
uint8_t g_status_Sys;                                       /* System status. 0: idle; 1: in judgment; 2: confirm; */
uint8_t g_status_Receive;                                   /* IR receive status. 1: in judgment; 2: right; 3: error */
uint8_t g_flag_SysOperation;                                /* About 400ms by WDTINT */
uint8_t g_flag_TAU01;                                       /* TAU01 flag, 12.5us (IR carrier output) */
uint8_t g_flag_INTP0;                                       /* INTP0 flag, falling and rising edge */
uint8_t g_ir_Length[8] = {32, 32, 64, 32, 32, 32, 64, 32};  /* Time = n*12.5us (40kHz IR) */
uint8_t g_ir_Cntl[8] = {1, 0, 1, 0, 1, 0, 1, 0};            /* 1: output IR carrier; 0: output low level */
uint8_t g_order_Output;                                     /* Output sequence number */
uint8_t g_order_Receive;                                    /* Receive sequence number */
uint8_t g_counter_Receive;                                  /* Receive counter, 50us increase by TAU00 (IR receive measure) */
uint8_t g_counter_Output;                                   /* Output counter, 12.5us (IR carrier output) */
uint8_t g_counter_LedOutput;                                /* Led counter, lighting LED lamp for 10 seconds */
uint8_t temp_order;
uint8_t temp_counter;
uint8_t temp_difference;

/***********************************************************************************************************************
* Function Name: R_IR_Process
* Description  : This function implements infrared process.
* Arguments    : None
* Return Value : None
***********************************************************************************************************************/
void R_IR_Process(void)
{
    switch (g_status_Sys)
    {
        case 0:                                             /* SystemStatus_Idle */
            if (1 == g_flag_SysOperation)                   /* 400ms */
            {
                g_flag_SysOperation = 0U;                   /* Clear operation flag */
                g_order_Output = 0U;                        /* Clear order */
                g_counter_Output = 0U;                      /* Clear counter */
                R_TAU0_Channel1_Start();                    /* TAU01 Output */
                g_order_Receive = 0U;                       /* Clear order */
                g_counter_Receive = 0U;                     /* Clear counter */
                R_INTC0_Start();                            /* IR receive enable */
                g_status_Sys = SYSST_INJUDGEMENT;           /* Trun to SystemStatus_InJudgment */
            }
            break;
        case 1:                                             /* SystemStatus_InJudgment */
            R_IR_Output();                                  /* IR output */
            R_IR_Receive();                                 /* IR receive */
            if (2 == g_status_Receive)                      /* Human detected */
            {
                g_status_Sys = SYSST_CONFIRM;               /* Trun to SystemStatus_Confirm */
                P0_bit.no0 = 1U;                            /* Light LED lamp */
                g_status_Receive = 0U;                      /* Clear receive flag */
            }
            else if (3 == g_status_Receive)                 /* IR receive error */
            {
                R_TAU0_Channel0_Stop();                     /* Stop IR receive measure by TAU00 */
                R_INTC0_Stop();                             /* Disable IR data input by INTP0 */
                g_status_Receive = 0U;                      /* Clear receive flag */
            }
            break;
        case 2:                                             /* SystemStatus_Confirm */
            R_LED_Drive();                                  /* Light LED lamp for 10 secondes */
            break;
        default:
            g_status_Sys = SYSST_IDLE;                      /* Trun to SystemStatus_Idle */
            g_flag_SysOperation = 0U;                       /* Clear operation flag */
            break;
    }
}

/***********************************************************************************************************************
* Function Name: R_IR_Output
* Description  : This function drive IR transmitter to output IR carrier waveform.
* Arguments    : None
* Return Value : None
***********************************************************************************************************************/
void R_IR_Output(void)
{
    uint8_t temp_cntl;
    uint8_t temp_length;
    if (1U == g_flag_TAU01)
    {
        temp_cntl = g_ir_Cntl[g_order_Output];               /* temp_cntl = 0/1; 1: output IR carrier; 0: output low level */
        temp_length = g_ir_Length[g_order_Output];           /* Time = temp_length*12.5us (40kHz IR) */
        g_counter_Output++;                                  /* IR output counter */
        if (1U == temp_cntl)                                 /* output IR carrier */
        {
            TOE0_bit.no1 = 1U;                               /* TAU ch1 output enable */
        }
        else                                                 /* output low level */
        {
            TOE0_bit.no1 = 0U;                                    /* TAU ch1 output disable */
            TO0 = 0x00U;                                     /* TAU ch1 output 0 */
        }

        if (g_counter_Output >= temp_length)                 /* half-bit waveform output completed */
        {
            g_order_Output++;
            g_counter_Output = 0U;
        }

        if (g_order_Output >= 8U)                            /* The last bit waveform output completed */
        {
            g_counter_Output = 0U;                           /* Clear output counter */
            g_order_Output = 0U;                             /* Clear output order */
            TOE0_bit.no1 = 0U;                                    /* TAU ch1 output disable */
            TO0 = 0x00U;                                     /* TAU ch1 output 0 */
            R_TAU0_Channel1_Stop();                          /* Stop TAU ch1 counter */
        }
    }
    g_flag_TAU01 = 0U;                                       /* Clear TAU01 flag */
}

/***********************************************************************************************************************
* Function Name: R_IR_Receive
* Description  : This function test the waveform of IR receiver module.
* Arguments    : None
* Return Value : None
***********************************************************************************************************************/
void R_IR_Receive(void)
{

    if (1U == g_flag_INTP0)                                   /* INTP0 operation flag */
    {
        g_order_Receive++;                                    /* Receive order for data array */
        temp_order = g_order_Receive - 1;
        if (temp_order <= 0)                                  /* The first edge */
        {
            g_counter_Receive = 0U;                           /* clear receive counter for waveform measure */
            R_TAU0_Channel0_Start();                          /* Start TAU ch0 counter */
        }
        else if ((temp_order >= 1U) && (temp_order <= 6U))    /* Store receive counter value for waveform measure */
        {
            temp_counter = g_ir_Length[temp_order - 1] >> 2U; /* Data array addressing */
            /* Calculate difference for waveform measure */
            if (g_counter_Receive > temp_counter)
            {
                temp_difference = g_counter_Receive - temp_counter;
            }
            else
            {
                temp_difference = temp_counter - g_counter_Receive;
            }
            /* Difference judge */
            if (temp_difference <= 3U)                        /* Within the error range */
            {
                g_status_Receive = 1U;                        /* Receive In judgment */
            }
            else                                              /* Out of the error range */
            {
                g_status_Receive = 3U;                        /* Error */
            }
        }
        else if (temp_order >= 7U)                            /* The last edge */
        {
            R_INTC0_Stop();                                   /* Disable INTP0 */
            temp_counter = g_ir_Length[temp_order - 1] >> 2U; /* Data array addressing */
            /* Calculate difference for waveform measure */
            if (g_counter_Receive > temp_counter)
            {
                temp_difference = g_counter_Receive - temp_counter;
            }
            else
            {
                temp_difference = temp_counter - g_counter_Receive;
            }
            /* Difference judge */
            if (temp_difference <= 3U)                        /* Within the error range */
            {
                g_status_Receive = 2U;                        /* Receive Confirmed */
            }
            else                                              /* Out of the error range */
            {
                g_status_Receive = 3U;                        /* Receive Error */
            }
        }
        g_counter_Receive = 0U;                               /* Clear receive counter for waveform measure */
    }
    if (g_counter_Receive >= 256U)                            /* Prevent counter overflow */
    {
        g_status_Receive = 3U;                                /* Receive Error */
    }
    g_flag_INTP0 = 0U;                                        /* Clear INTP0 flag */
}

/***********************************************************************************************************************
* Function Name: R_LED_Drive
* Description  : This function drive high light LED lamp and relay.
* Arguments    : None
* Return Value : None
***********************************************************************************************************************/
void R_LED_Drive(void)
{
    if (1U == g_flag_SysOperation)                          /* 400ms */
    {
        g_counter_LedOutput++;                              /* LED output counter */
        P0_bit.no0 = 1U;                                    /* P0.0 output 1, light LED lamp and open relay */
    }
    if (25U <= g_counter_LedOutput)                         /* 10S */
    {
        g_status_Sys = SYSST_IDLE;                          /* Trun to SystemStatus_Idle */
        g_counter_LedOutput = 0U;                           /* Clear LED output counter */
        P0_bit.no0 = 0U;                                    /* P0.0 output 0, close LED lamp and relay */
    }
    g_flag_SysOperation = 0U;                               /* Clear operation flag */
}